# Portfolio Website

## Overview

This is a personal portfolio website for Pooja Patil, a BCA student and web developer. The application is built as a single-page React application showcasing professional work, skills, education, certifications, and contact information. The site features a modern, responsive design with smooth scrolling navigation between sections including Hero, About, Skills, Projects, Certifications, and Contact.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build System**
- **React 18** with TypeScript for type-safe component development
- **Vite** as the build tool and development server, providing fast HMR (Hot Module Replacement)
- **Wouter** for lightweight client-side routing (though currently only serving a single portfolio page)
- **TanStack Query** for data fetching and state management (currently minimal usage as data is static)

**UI Component System**
- **Shadcn/ui** component library built on Radix UI primitives
- **Tailwind CSS** for utility-first styling with custom design tokens
- Component architecture follows the "New York" style variant from Shadcn
- Custom CSS variables for theming supporting both light and dark modes

**Design System**
- Typography: Inter for primary text, JetBrains Mono for code snippets
- Color palette optimized for dark mode with vibrant blue accents (220 90% 58%)
- Responsive spacing system using Tailwind's standardized units (4, 6, 8, 12, 16, 20, 24)
- Custom hover and active states via `hover-elevate` and `active-elevate-2` utility classes

**Data Management**
- Static portfolio data stored in `/client/src/data/portfolioData.ts`
- Type-safe data structures defined with Zod schemas in `/shared/schema.ts`
- No dynamic data fetching currently implemented

### Backend Architecture

**Server Framework**
- **Express.js** server with TypeScript
- Development and production modes configured via NODE_ENV
- Custom request logging middleware for API endpoints

**Build & Deployment**
- Development: TSX for TypeScript execution with hot reload
- Production: ESBuild bundles server code, Vite builds client assets
- Static assets served from `dist/public` in production

**Storage Interface**
- Abstract `IStorage` interface defined in `server/storage.ts`
- In-memory implementation (`MemStorage`) currently active
- Designed for future database integration (basic User CRUD operations defined)
- Session management ready via `connect-pg-simple` dependency

### Data Storage

**Current Implementation**
- No database currently connected
- Portfolio data hardcoded in TypeScript files

**Prepared Infrastructure**
- Drizzle ORM configured for PostgreSQL via `@neondatabase/serverless`
- Database schema location: `./shared/schema.ts`
- Migrations directory: `./migrations`
- Ready for Neon serverless PostgreSQL deployment

**Schema Design Philosophy**
- Zod schemas provide runtime validation and TypeScript types
- Shared schema definitions between client and server via `/shared` directory
- Currently defines: Project, Education, SkillCategory, Certification, ContactInfo types

### File Structure & Path Aliases

**Monorepo Organization**
- `/client` - React frontend application
- `/server` - Express backend application  
- `/shared` - Shared TypeScript types and schemas
- `/attached_assets` - Static assets (referenced but not included in provided files)

**TypeScript Path Aliases**
- `@/*` → `/client/src/*`
- `@shared/*` → `/shared/*`
- `@assets/*` → `/attached_assets/*`

### Development & Testing

**Development Tools**
- Replit-specific plugins for enhanced development experience (cartographer, dev-banner, runtime-error-modal)
- TypeScript strict mode enabled with ESNext module resolution
- Component test IDs embedded throughout for testing infrastructure

**Code Quality**
- Incremental TypeScript compilation
- ESLint and Prettier configurations (implied by tooling choices)
- Consistent component naming and file organization

## External Dependencies

### UI & Component Libraries
- **Radix UI** - Complete suite of accessible, unstyled UI primitives (accordion, dialog, dropdown, popover, etc.)
- **Shadcn/ui** - Pre-built component library built on Radix primitives
- **Lucide React** - Icon library for UI elements
- **Tailwind CSS** - Utility-first CSS framework
- **class-variance-authority** - Type-safe variant styling utility
- **cmdk** - Command menu component

### State & Data Management
- **TanStack Query (React Query)** - Server state management and caching
- **React Hook Form** - Form state management with `@hookform/resolvers`
- **Zod** - Runtime schema validation and TypeScript type inference
- **date-fns** - Date manipulation utilities

### Backend Services
- **Express.js** - Web application framework
- **Drizzle ORM** - TypeScript ORM for SQL databases
- **@neondatabase/serverless** - Neon serverless PostgreSQL driver
- **connect-pg-simple** - PostgreSQL session store for Express

### Build & Development Tools
- **Vite** - Frontend build tool and dev server
- **esbuild** - JavaScript bundler for production server builds
- **tsx** - TypeScript execution engine for development
- **PostCSS & Autoprefixer** - CSS processing pipeline

### Routing
- **Wouter** - Lightweight client-side routing library

### Google Fonts
- Inter (weights 100-900)
- JetBrains Mono (weights 100-800)

### Replit Integrations
- `@replit/vite-plugin-runtime-error-modal`
- `@replit/vite-plugin-cartographer`
- `@replit/vite-plugin-dev-banner`