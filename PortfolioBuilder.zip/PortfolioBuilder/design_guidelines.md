# Portfolio Website Design Guidelines

## Design Approach
**Reference-Based Approach** - Drawing inspiration from leading portfolio platforms (Behance, Adobe Portfolio, Dribbble) with focus on visual storytelling and professional presentation.

**Core Principle**: Create an impressive, memorable first impression while maintaining effortless navigation through accomplishments and work.

---

## Color Palette

**Dark Mode Primary** (Professional & Modern):
- Background Base: 222 15% 8%
- Surface: 222 12% 12%
- Primary Accent: 220 90% 58% (Vibrant blue for CTAs and highlights)
- Text Primary: 0 0% 98%
- Text Secondary: 220 10% 70%

**Light Mode Alternative**:
- Background: 0 0% 98%
- Surface: 0 0% 100%
- Primary Accent: 220 85% 55%
- Text Primary: 222 15% 12%
- Text Secondary: 220 8% 45%

---

## Typography

**Font Stack**:
- Primary: 'Inter' (Google Fonts) - Headings, UI elements
- Secondary: 'JetBrains Mono' (Google Fonts) - Code snippets, technical details (if applicable)

**Hierarchy**:
- Hero Name: text-6xl md:text-7xl lg:text-8xl font-bold
- Section Headings: text-4xl md:text-5xl font-bold
- Subsections: text-2xl md:text-3xl font-semibold
- Body: text-base md:text-lg leading-relaxed
- Captions: text-sm text-secondary

---

## Layout System

**Spacing Primitives**: Use Tailwind units of **4, 6, 8, 12, 16, 20, 24** consistently.
- Section padding: py-20 md:py-32
- Container max-width: max-w-7xl
- Content max-width: max-w-4xl for text-heavy sections
- Grid gaps: gap-6 md:gap-8 lg:gap-12

**Responsive Breakpoints**:
- Mobile-first approach
- md: Tablet adjustments
- lg: Desktop optimizations

---

## Page Structure & Sections

### 1. Hero Section (Full Viewport Impact)
- **Layout**: Full-screen (min-h-screen) with professional photo as background or prominent foreground
- **Content**: Name in large, bold typography + tagline/role + primary CTA
- **Visual Treatment**: Subtle gradient overlay on background image, frosted-glass effect on text container
- **CTA Buttons**: "View Work" (primary) + "Download Resume" (outline with backdrop-blur)

### 2. About Me Section
- **Layout**: 2-column on desktop (photo + bio), stacked on mobile
- **Content**: Professional photo (if not in hero), compelling bio (3-4 paragraphs), key skills/highlights as badges
- **Visual Elements**: Floating skill tags with subtle animations, professional headshot with rounded corners and subtle shadow

### 3. Portfolio Gallery
- **Layout**: Masonry grid (2 cols mobile, 3 cols tablet, 4 cols desktop) using grid-cols-1 md:grid-cols-3 lg:grid-cols-4
- **Card Design**: Portfolio items with image preview, project title overlay on hover, subtle scale transform
- **Interaction**: Click to expand/modal view with project details
- **Categories**: Optional filter tabs if multiple project types

### 4. Resume/Experience Section
- **Layout**: Timeline-style for experience, grid for skills
- **Content Blocks**: Company/Role cards with dates, descriptions, and key achievements
- **Skills**: Visual skill bars or proficiency indicators (avoid generic circle charts)
- **Download CTA**: Prominent "Download Full Resume" button

### 5. Certificates/Achievements
- **Layout**: Card grid (2 cols mobile, 3 cols desktop) for certificate images
- **Card Design**: Certificate preview image, issuer name, date, verification link
- **Visual Treatment**: Clean white/light borders, subtle hover lift effect

### 6. Contact Section
- **Layout**: Centered content with contact methods as large, clickable cards
- **Content**: Email, LinkedIn, GitHub, other social links as visual cards
- **CTA**: "Let's Connect" headline with supporting text
- **Footer Integration**: Minimal footer with copyright and quick links

---

## Component Library

**Navigation**: Fixed header with logo/name on left, smooth-scroll nav links on right, hamburger on mobile
**Buttons**: Rounded (rounded-lg), solid primary + outline variants with backdrop-blur
**Cards**: Rounded corners (rounded-xl), subtle shadow, hover lift (hover:-translate-y-1)
**Images**: Aspect ratio containers, lazy loading, subtle zoom on hover for gallery items
**Icons**: Heroicons (via CDN) for UI elements

---

## Images

**Hero Section**: 
- Large, high-quality professional photograph (headshot or creative portrait)
- Image should convey personality and professionalism
- Placement: Background with overlay or prominent foreground element

**About Section**:
- Professional headshot (if not used in hero)
- Rounded or artistic frame treatment

**Portfolio Gallery**:
- User-provided portfolio work images
- Maintain aspect ratios, use object-cover for consistency

**Certificates Section**:
- Scanned/photographed certificate images
- Displayed in clean, organized grid

**Overall Image Strategy**: Visual-heavy approach with high-quality imagery throughout to create impressive, professional presentation.

---

## Animations (Minimal & Purposeful)

- Smooth scroll behavior between sections
- Fade-in on scroll for section entries (Intersection Observer)
- Subtle hover effects (scale, lift) on interactive elements
- No distracting parallax or excessive motion

---

## Accessibility & Quality

- Maintain WCAG AA contrast ratios
- Keyboard navigation support
- Semantic HTML structure
- Alt text for all images
- Focus states for interactive elements
- Responsive images with srcset