import { z } from "zod";

// Portfolio data types
export const projectSchema = z.object({
  id: z.string(),
  title: z.string(),
  description: z.string(),
  technologies: z.array(z.string()),
  category: z.string(),
  imageUrl: z.string().optional(),
});

export const educationSchema = z.object({
  degree: z.string(),
  institution: z.string(),
  period: z.string(),
  cgpa: z.string().optional(),
});

export const skillCategorySchema = z.object({
  category: z.string(),
  skills: z.array(z.string()),
});

export const certificationSchema = z.object({
  id: z.string(),
  title: z.string(),
  issuer: z.string(),
  description: z.string(),
  imageUrl: z.string().optional(),
});

export const contactInfoSchema = z.object({
  email: z.string(),
  phone: z.string(),
  linkedin: z.string(),
  github: z.string(),
  location: z.string(),
});

export type Project = z.infer<typeof projectSchema>;
export type Education = z.infer<typeof educationSchema>;
export type SkillCategory = z.infer<typeof skillCategorySchema>;
export type Certification = z.infer<typeof certificationSchema>;
export type ContactInfo = z.infer<typeof contactInfoSchema>;
