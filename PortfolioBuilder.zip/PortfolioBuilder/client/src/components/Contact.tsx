import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { contactInfo } from "@/data/portfolioData";
import { Mail, Phone, MapPin, Github, Linkedin, ExternalLink } from "lucide-react";

export default function Contact() {
  return (
    <section id="contact" className="py-20 md:py-32 px-4 sm:px-6 lg:px-8 bg-background">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-center mb-4 md:mb-6" data-testid="heading-contact">
          Let's Connect
        </h2>
        <p className="text-center text-muted-foreground mb-12 md:mb-16 max-w-2xl mx-auto text-base md:text-lg" data-testid="text-contact-intro">
          I'm always open to discussing new projects, opportunities, or collaborations
        </p>

        <div className="grid md:grid-cols-2 gap-6 md:gap-8 mb-12">
          {/* Email */}
          <Card className="hover-elevate active-elevate-2 transition-all duration-300">
            <CardContent className="p-6 md:p-8">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-primary/10 rounded-lg">
                  <Mail className="h-6 w-6 text-primary" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold mb-2" data-testid="text-contact-email-label">Email</h3>
                  <a
                    href={`mailto:${contactInfo.email}`}
                    className="text-muted-foreground hover:text-primary transition-colors break-all"
                    data-testid="link-contact-email"
                  >
                    {contactInfo.email}
                  </a>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Phone */}
          <Card className="hover-elevate active-elevate-2 transition-all duration-300">
            <CardContent className="p-6 md:p-8">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-primary/10 rounded-lg">
                  <Phone className="h-6 w-6 text-primary" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold mb-2" data-testid="text-contact-phone-label">Phone</h3>
                  <a
                    href={`tel:${contactInfo.phone}`}
                    className="text-muted-foreground hover:text-primary transition-colors"
                    data-testid="link-contact-phone"
                  >
                    {contactInfo.phone}
                  </a>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Location */}
          <Card className="hover-elevate active-elevate-2 transition-all duration-300">
            <CardContent className="p-6 md:p-8">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-primary/10 rounded-lg">
                  <MapPin className="h-6 w-6 text-primary" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold mb-2" data-testid="text-contact-location-label">Location</h3>
                  <p className="text-muted-foreground" data-testid="text-contact-location">
                    {contactInfo.location}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* GitHub */}
          <Card className="hover-elevate active-elevate-2 transition-all duration-300">
            <CardContent className="p-6 md:p-8">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-primary/10 rounded-lg">
                  <Github className="h-6 w-6 text-primary" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold mb-2" data-testid="text-contact-github-label">GitHub</h3>
                  <a
                    href={contactInfo.github}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-muted-foreground hover:text-primary transition-colors inline-flex items-center gap-1"
                    data-testid="link-contact-github"
                  >
                    View Profile
                    <ExternalLink className="h-3 w-3" />
                  </a>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* LinkedIn CTA */}
        <Card className="bg-gradient-to-br from-primary/10 to-accent/10 border-primary/20">
          <CardContent className="p-6 md:p-8 text-center">
            <Linkedin className="h-12 w-12 text-primary mx-auto mb-4" />
            <h3 className="text-xl md:text-2xl font-bold mb-3" data-testid="text-linkedin-cta">
              Connect on LinkedIn
            </h3>
            <p className="text-muted-foreground mb-6" data-testid="text-linkedin-description">
              Let's connect professionally and stay in touch
            </p>
            <Button size="lg" asChild data-testid="button-linkedin-connect">
              <a href={contactInfo.linkedin} target="_blank" rel="noopener noreferrer">
                <Linkedin className="mr-2 h-5 w-5" />
                View LinkedIn Profile
              </a>
            </Button>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
