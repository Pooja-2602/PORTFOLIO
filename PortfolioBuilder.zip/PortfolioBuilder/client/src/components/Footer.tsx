import { Github, Linkedin, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";
import { contactInfo } from "@/data/portfolioData";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-muted/30 border-t border-border py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Brand */}
          <div className="text-center md:text-left">
            <h3 className="text-xl font-bold mb-2">Pooja Patil</h3>
            <p className="text-sm text-muted-foreground">
              Web & Software Developer
            </p>
          </div>

          {/* Social Links */}
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              asChild
              data-testid="footer-link-github"
            >
              <a href={contactInfo.github} target="_blank" rel="noopener noreferrer">
                <Github className="h-5 w-5" />
              </a>
            </Button>
            <Button
              variant="ghost"
              size="icon"
              asChild
              data-testid="footer-link-linkedin"
            >
              <a href={contactInfo.linkedin} target="_blank" rel="noopener noreferrer">
                <Linkedin className="h-5 w-5" />
              </a>
            </Button>
            <Button
              variant="ghost"
              size="icon"
              asChild
              data-testid="footer-link-email"
            >
              <a href={`mailto:${contactInfo.email}`}>
                <Mail className="h-5 w-5" />
              </a>
            </Button>
          </div>
        </div>

        {/* Copyright */}
        <div className="mt-8 pt-8 border-t border-border text-center text-sm text-muted-foreground">
          <p>© {currentYear} Pooja Patil. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
