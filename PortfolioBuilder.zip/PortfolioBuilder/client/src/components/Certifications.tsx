import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { certifications } from "@/data/portfolioData";
import { Award, Trophy, Medal, Star } from "lucide-react";

const certIcons = [Trophy, Award, Medal, Star];

export default function Certifications() {
  return (
    <section id="certifications" className="py-20 md:py-32 px-4 sm:px-6 lg:px-8 bg-muted/30">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-center mb-4 md:mb-6" data-testid="heading-certifications">
          Certifications & Achievements
        </h2>
        <p className="text-center text-muted-foreground mb-12 md:mb-16 max-w-3xl mx-auto text-base md:text-lg" data-testid="text-certifications-intro">
          Recognition of excellence, dedication, and continuous learning
        </p>

        <div className="grid md:grid-cols-2 gap-6 md:gap-8">
          {certifications.map((cert, index) => {
            const Icon = certIcons[index % certIcons.length];
            return (
              <Card
                key={cert.id}
                className="hover-elevate active-elevate-2 transition-all duration-300"
                data-testid={`card-certification-${cert.id}`}
              >
                <CardHeader>
                  <div className="flex items-start gap-4">
                    <div className="p-3 bg-primary/10 rounded-lg">
                      <Icon className="h-8 w-8 text-primary" />
                    </div>
                    <div className="flex-1">
                      <CardTitle className="text-lg md:text-xl mb-2" data-testid={`text-cert-title-${cert.id}`}>
                        {cert.title}
                      </CardTitle>
                      <Badge variant="secondary" className="text-xs" data-testid={`badge-cert-issuer-${cert.id}`}>
                        {cert.issuer}
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground text-sm leading-relaxed" data-testid={`text-cert-description-${cert.id}`}>
                    {cert.description}
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Additional Achievements */}
        <div className="mt-12 md:mt-16">
          <Card className="bg-gradient-to-br from-primary/5 to-accent/5 border-primary/20">
            <CardContent className="p-6 md:p-8">
              <h3 className="text-xl md:text-2xl font-bold mb-4" data-testid="heading-additional-achievements">
                Additional Achievements
              </h3>
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex items-start gap-2" data-testid="text-achievement-0">
                  <span className="text-primary mt-1">✓</span>
                  <span>Participated in Code Debugging & Web Design Competitions at college level</span>
                </li>
                <li className="flex items-start gap-2" data-testid="text-achievement-1">
                  <span className="text-primary mt-1">✓</span>
                  <span>Presented academic projects during Tech Fest Exhibition 2024</span>
                </li>
                <li className="flex items-start gap-2" data-testid="text-achievement-2">
                  <span className="text-primary mt-1">✓</span>
                  <span>Assisted peers in database query optimization and practical labs</span>
                </li>
                <li className="flex items-start gap-2" data-testid="text-achievement-3">
                  <span className="text-primary mt-1">✓</span>
                  <span>Cybersecurity Seminar Participant</span>
                </li>
                <li className="flex items-start gap-2" data-testid="text-achievement-4">
                  <span className="text-primary mt-1">✓</span>
                  <span>Event Coordinator - Training and Placement Cell</span>
                </li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
