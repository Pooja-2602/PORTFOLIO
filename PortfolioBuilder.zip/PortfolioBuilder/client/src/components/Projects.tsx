import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { projects } from "@/data/portfolioData";
import { Folder, Award } from "lucide-react";

export default function Projects() {
  return (
    <section id="projects" className="py-20 md:py-32 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-background via-primary/5 to-background relative overflow-hidden">
      {/* Background Decoration */}
      <div className="absolute top-20 right-20 w-72 h-72 bg-primary/5 rounded-full blur-3xl"></div>
      <div className="absolute bottom-20 left-20 w-96 h-96 bg-accent/5 rounded-full blur-3xl"></div>
      
      <div className="max-w-7xl mx-auto relative z-10">
        <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-center mb-4 md:mb-6" data-testid="heading-projects">
          Projects
        </h2>
        <p className="text-center text-muted-foreground mb-12 md:mb-16 max-w-3xl mx-auto text-base md:text-lg" data-testid="text-projects-intro">
          Explore my portfolio of academic and professional projects showcasing various technologies
        </p>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {projects.map((project, index) => (
            <Card
              key={project.id}
              className="hover-elevate active-elevate-2 transition-all duration-300 flex flex-col border-primary/20 shadow-lg hover:shadow-2xl hover:-translate-y-2"
              data-testid={`card-project-${project.id}`}
            >
              <CardHeader>
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="p-2 bg-gradient-to-br from-primary/20 to-accent/20 rounded-lg">
                    {index < 3 ? (
                      <Award className="h-6 w-6 text-primary" />
                    ) : (
                      <Folder className="h-6 w-6 text-primary" />
                    )}
                  </div>
                  <Badge variant="outline" className="text-xs" data-testid={`badge-category-${project.id}`}>
                    {project.category}
                  </Badge>
                </div>
                <CardTitle className="text-xl" data-testid={`text-project-title-${project.id}`}>
                  {project.title}
                </CardTitle>
              </CardHeader>
              <CardContent className="flex-1">
                <p className="text-muted-foreground text-sm leading-relaxed" data-testid={`text-project-description-${project.id}`}>
                  {project.description}
                </p>
              </CardContent>
              <CardFooter className="flex-wrap gap-2 pt-4 border-t">
                {project.technologies.map((tech, techIndex) => (
                  <Badge key={techIndex} variant="secondary" className="text-xs hover:bg-primary/20 transition-colors" data-testid={`badge-tech-${project.id}-${techIndex}`}>
                    {tech}
                  </Badge>
                ))}
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
