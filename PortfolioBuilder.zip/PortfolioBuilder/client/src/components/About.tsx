import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { areasOfInterest, education, languages, hobbies } from "@/data/portfolioData";
import { GraduationCap, Lightbulb, Globe, Heart } from "lucide-react";

export default function About() {
  return (
    <section id="about" className="py-20 md:py-32 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-background via-muted/20 to-background relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>
      
      <div className="max-w-6xl mx-auto relative z-10">
        <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-center mb-4 md:mb-6" data-testid="heading-about">
          About Me
        </h2>
        <p className="text-center text-muted-foreground mb-12 md:mb-16 max-w-3xl mx-auto text-base md:text-lg" data-testid="text-about-intro">
          Get to know more about my background, interests, and what drives my passion for technology
        </p>

        <div className="grid md:grid-cols-2 gap-8 mb-12">
          {/* Profile Summary */}
          <Card className="hover-elevate border-primary/20 shadow-lg hover:shadow-xl transition-all duration-300">
            <CardContent className="p-6 md:p-8">
              <h3 className="text-xl md:text-2xl font-bold mb-4 flex items-center gap-2" data-testid="heading-profile-summary">
                <GraduationCap className="h-6 w-6 text-primary" />
                Profile Summary
              </h3>
              <p className="text-muted-foreground leading-relaxed mb-6" data-testid="text-profile-summary-1">
                Energetic and hardworking BCA student with a strong foundation in programming,
                database systems, and web development. Passionate about creating real-world IT
                solutions using ASP.NET, PHP, and SQL Server.
              </p>
              <p className="text-muted-foreground leading-relaxed" data-testid="text-profile-summary-2">
                Skilled in backend logic, UI design, and state management using sessions and cookies.
                Proven team player with excellent problem-solving, innovation, and collaboration skills.
              </p>
            </CardContent>
          </Card>

          {/* Education */}
          <Card className="hover-elevate border-primary/20 shadow-lg hover:shadow-xl transition-all duration-300">
            <CardContent className="p-6 md:p-8">
              <h3 className="text-xl md:text-2xl font-bold mb-4 flex items-center gap-2" data-testid="heading-education">
                <GraduationCap className="h-6 w-6 text-primary" />
                Education
              </h3>
              {education.map((edu, index) => (
                <div key={index} className="space-y-2">
                  <h4 className="font-semibold text-lg" data-testid={`text-degree-${index}`}>{edu.degree}</h4>
                  <p className="text-muted-foreground" data-testid={`text-institution-${index}`}>{edu.institution}</p>
                  <div className="flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
                    <span data-testid={`text-period-${index}`}>{edu.period}</span>
                    {edu.cgpa && (
                      <>
                        <span>•</span>
                        <Badge variant="secondary" data-testid={`badge-cgpa-${index}`}>CGPA: {edu.cgpa}</Badge>
                      </>
                    )}
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Areas of Interest */}
          <Card className="hover-elevate border-primary/20 shadow-lg hover:shadow-xl transition-all duration-300">
            <CardContent className="p-6 md:p-8">
              <h3 className="text-xl md:text-2xl font-bold mb-4 flex items-center gap-2" data-testid="heading-interests">
                <Lightbulb className="h-6 w-6 text-primary" />
                Areas of Interest
              </h3>
              <div className="flex flex-wrap gap-2">
                {areasOfInterest.map((interest, index) => (
                  <Badge key={index} variant="secondary" className="text-sm hover:bg-primary/20 transition-colors" data-testid={`badge-interest-${index}`}>
                    {interest}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Languages & Hobbies */}
          <div className="space-y-8">
            <Card className="hover-elevate border-primary/20 shadow-lg hover:shadow-xl transition-all duration-300">
              <CardContent className="p-6 md:p-8">
                <h3 className="text-xl font-bold mb-4 flex items-center gap-2" data-testid="heading-languages">
                  <Globe className="h-6 w-6 text-primary" />
                  Languages
                </h3>
                <div className="flex flex-wrap gap-2">
                  {languages.map((language, index) => (
                    <Badge key={index} variant="outline" className="hover:bg-primary/10 transition-colors" data-testid={`badge-language-${index}`}>
                      {language}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="hover-elevate border-primary/20 shadow-lg hover:shadow-xl transition-all duration-300">
              <CardContent className="p-6 md:p-8">
                <h3 className="text-xl font-bold mb-4 flex items-center gap-2" data-testid="heading-hobbies">
                  <Heart className="h-6 w-6 text-primary" />
                  Hobbies
                </h3>
                <ul className="text-muted-foreground space-y-2">
                  {hobbies.map((hobby, index) => (
                    <li key={index} className="flex items-start gap-2" data-testid={`text-hobby-${index}`}>
                      <span className="text-primary mt-1">•</span>
                      <span>{hobby}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
