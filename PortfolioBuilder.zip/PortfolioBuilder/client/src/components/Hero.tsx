import { ArrowDown, Download, Github, Linkedin, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";
import { contactInfo } from "@/data/portfolioData";

export default function Hero() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  const handleDownloadResume = () => {
    const link = document.createElement('a');
    link.href = '/resume.pdf';
    link.download = 'Pooja_Patil_Resume.pdf';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <section
      id="home"
      className="min-h-screen flex items-center justify-center relative overflow-hidden px-4 sm:px-6 lg:px-8"
    >
      {/* Animated Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-background to-accent/20">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(120,119,198,0.1),transparent_50%)]"></div>
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/50 to-transparent"></div>
        <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-accent/50 to-transparent"></div>
      </div>

      {/* Floating Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-primary/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      <div className="max-w-5xl mx-auto text-center py-20 md:py-32 relative z-10">
        {/* Profile Image Placeholder */}
        <div className="mb-8 md:mb-12 flex justify-center">
          <div className="w-32 h-32 md:w-40 md:h-40 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-primary-foreground text-5xl md:text-6xl font-bold shadow-2xl hover:scale-110 transition-transform duration-300" data-testid="img-profile">
            PP
          </div>
        </div>

        {/* Name and Title */}
        <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-foreground mb-4 md:mb-6 bg-clip-text text-transparent bg-gradient-to-r from-foreground via-primary to-foreground" data-testid="text-name">
          Pooja Patil
        </h1>
        <p className="text-xl sm:text-2xl md:text-3xl text-muted-foreground mb-6 md:mb-8" data-testid="text-title">
          BCA Student | Web & Software Developer
        </p>

        {/* Description */}
        <p className="text-base md:text-lg text-muted-foreground max-w-2xl mx-auto mb-8 md:mb-12 leading-relaxed" data-testid="text-hero-description">
          Passionate about creating real-world IT solutions using ASP.NET, PHP, and SQL Server.
          Award-winning developer with proven skills in full-stack development and database management.
        </p>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12 md:mb-16">
          <Button
            size="lg"
            onClick={() => scrollToSection("projects")}
            className="w-full sm:w-auto shadow-lg hover:shadow-xl transition-shadow"
            data-testid="button-view-work"
          >
            View My Work
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="w-full sm:w-auto backdrop-blur-sm bg-background/50 hover:bg-background/80 shadow-lg"
            onClick={handleDownloadResume}
            data-testid="button-download-resume"
          >
            <Download className="mr-2 h-5 w-5" />
            Download Resume
          </Button>
        </div>

        {/* Social Links */}
        <div className="flex items-center justify-center gap-4 mb-12 md:mb-16">
          <Button
            variant="ghost"
            size="icon"
            className="rounded-full bg-muted/50 hover:bg-primary/20 transition-all"
            asChild
            data-testid="link-github"
          >
            <a href={contactInfo.github} target="_blank" rel="noopener noreferrer">
              <Github className="h-6 w-6" />
            </a>
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="rounded-full bg-muted/50 hover:bg-primary/20 transition-all"
            asChild
            data-testid="link-linkedin"
          >
            <a href={contactInfo.linkedin} target="_blank" rel="noopener noreferrer">
              <Linkedin className="h-6 w-6" />
            </a>
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="rounded-full bg-muted/50 hover:bg-primary/20 transition-all"
            asChild
            data-testid="link-email"
          >
            <a href={`mailto:${contactInfo.email}`}>
              <Mail className="h-6 w-6" />
            </a>
          </Button>
        </div>

        {/* Scroll Indicator */}
        <button
          onClick={() => scrollToSection("about")}
          className="inline-flex items-center justify-center animate-bounce text-muted-foreground hover:text-foreground transition-colors"
          data-testid="button-scroll-down"
        >
          <ArrowDown className="h-8 w-8" />
        </button>
      </div>
    </section>
  );
}
