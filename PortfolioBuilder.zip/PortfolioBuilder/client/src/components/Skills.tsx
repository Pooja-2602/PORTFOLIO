import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { skillCategories } from "@/data/portfolioData";
import { Code, Database, Wrench, Globe } from "lucide-react";

const categoryIcons: Record<string, any> = {
  "Programming Languages": Code,
  "Web Development": Globe,
  "Databases": Database,
  "Tools & Platforms": Wrench,
};

export default function Skills() {
  return (
    <section id="skills" className="py-20 md:py-32 px-4 sm:px-6 lg:px-8 bg-muted/30">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-center mb-4 md:mb-6" data-testid="heading-skills">
          Technical Skills
        </h2>
        <p className="text-center text-muted-foreground mb-12 md:mb-16 max-w-3xl mx-auto text-base md:text-lg" data-testid="text-skills-intro">
          A comprehensive overview of my technical expertise and tools I work with
        </p>

        <div className="grid md:grid-cols-2 gap-6 md:gap-8">
          {skillCategories.map((category, index) => {
            const Icon = categoryIcons[category.category] || Code;
            return (
              <Card key={index} className="hover-elevate" data-testid={`card-skill-category-${index}`}>
                <CardContent className="p-6 md:p-8">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="p-2 bg-primary/10 rounded-lg">
                      <Icon className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="text-xl md:text-2xl font-bold" data-testid={`text-skill-category-${index}`}>
                      {category.category}
                    </h3>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {category.skills.map((skill, skillIndex) => (
                      <Badge
                        key={skillIndex}
                        variant="secondary"
                        className="text-sm px-3 py-1"
                        data-testid={`badge-skill-${index}-${skillIndex}`}
                      >
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Tech Stack Summary */}
        <div className="mt-12 md:mt-16">
          <Card className="bg-gradient-to-br from-primary/5 to-accent/5 border-primary/20">
            <CardContent className="p-6 md:p-8">
              <h3 className="text-xl md:text-2xl font-bold mb-4 text-center" data-testid="heading-tech-stack">
                Tech Stack Summary
              </h3>
              <p className="text-center text-base md:text-lg font-mono text-muted-foreground" data-testid="text-tech-stack">
                ASP.NET • PHP • SQL Server • HTML • CSS • Bootstrap • Java • MySQL
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
