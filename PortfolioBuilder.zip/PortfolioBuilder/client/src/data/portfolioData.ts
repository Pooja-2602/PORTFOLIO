import type { Project, Education, SkillCategory, Certification, ContactInfo } from "@shared/schema";

export const contactInfo: ContactInfo = {
  email: "patilpooja02102005@gmail.com",
  phone: "7984802763",
  linkedin: "https://www.linkedin.com/in/pooja-patil-ab727028b",
  github: "https://github.com/Pooja-2602",
  location: "Surat, Gujarat",
};

export const education: Education[] = [
  {
    degree: "Bachelor of Computer Applications (BCA)",
    institution: "Vanita Vishram Women's University, Surat",
    period: "2023 – 2026",
    cgpa: "8.91 / 10",
  },
];

export const skillCategories: SkillCategory[] = [
  {
    category: "Programming Languages",
    skills: ["C", "C++", "Java", "Python"],
  },
  {
    category: "Web Development",
    skills: ["HTML", "CSS", "Bootstrap", "jQuery", "PHP", "ASP.NET"],
  },
  {
    category: "Databases",
    skills: ["SQL Server", "MySQL", "DBMS", "RDBMS"],
  },
  {
    category: "Tools & Platforms",
    skills: ["Visual Studio", "XAMPP", "WAMP", "GitHub", "Canva", "Git"],
  },
];

export const projects: Project[] = [
  {
    id: "1",
    title: "MindMate – Mental Health Support Platform",
    description: "Developed a PHP-based mental health web platform with modules for students, counsellors, and psychologists. Used sessions, cookies, and query strings for secure login, communication, and user-specific session tracking. Includes features like mood tracking, counselling appointment booking, color therapy, and secure record management.",
    technologies: ["PHP", "SQL Server", "Sessions & Cookies", "Query Strings"],
    category: "Web Application",
  },
  {
    id: "2",
    title: "Smart Surat – City Service Management",
    description: "Developed a city service management web application using ASP.NET with SQL Server integration. Implemented Master Page for consistent layout, user authentication, complaint registration, feedback handling, and admin dashboard for monitoring city services.",
    technologies: ["ASP.NET", "SQL Server", "Master Page", "Authentication"],
    category: "Web Application",
  },
  {
    id: "3",
    title: "Library Management System",
    description: "Developed a standalone application to manage book records, member details, and book issuance/return operations. Implemented object-oriented concepts like classes, inheritance, and exception handling to simplify library workflows.",
    technologies: ["C++", "Java", "Python", "RDBMS", "OOP"],
    category: "Desktop Application",
  },
  {
    id: "4",
    title: "Employee Management System",
    description: "Developed a standalone Java-based system for managing employee details, attendance, and salary records. Implemented inheritance, constructors, and exception handling without database connectivity. Focused on modular design and data validation.",
    technologies: ["Java", "OOP", "Exception Handling"],
    category: "Desktop Application",
  },
  {
    id: "5",
    title: "Medical Store Website",
    description: "Designed and developed a responsive front-end website for browsing and purchasing medicines. Implemented categorized product sections, search bar, and contact forms to enhance user experience. Ensured adaptive design using Bootstrap for seamless performance across devices.",
    technologies: ["HTML", "CSS", "Bootstrap", "Responsive Design"],
    category: "Frontend",
  },
  {
    id: "6",
    title: "Blog & Education Websites",
    description: "Created attractive, mobile-friendly websites for blogs and educational content using HTML, CSS, and Bootstrap. Integrated structured layouts with navigation menus, gallery sections, and content grids for readability and engagement.",
    technologies: ["HTML", "CSS", "Bootstrap"],
    category: "Frontend",
  },
];

export const certifications: Certification[] = [
  {
    id: "1",
    title: "SWAYAM–NPTEL Course on Internet of Things",
    issuer: "NPTEL (Government-approved)",
    description: "3-credit course with 70% score, covering IoT fundamentals, applications, and implementation.",
  },
  {
    id: "2",
    title: "2nd Place – Query DB Tech Fest",
    issuer: "College Tech Fest",
    description: "Solved complex SQL queries, triggers, and stored procedures under a 1-hour challenge.",
  },
  {
    id: "3",
    title: "2nd Position – Innovation Hackathon",
    issuer: "College Hackathon (Mental Health Domain)",
    description: "Recognized for developing MindMate – Mental Health Support Platform featuring AI chat support, mood tracker, color therapy, interactive games, and secure SQL Server backend.",
  },
  {
    id: "4",
    title: "Event Management Certification",
    issuer: "Training & Placement Cell",
    description: "Successfully completed event coordination and management activities, demonstrating leadership, planning, and communication skills.",
  },
];

export const areasOfInterest = [
  "Web Application Development",
  "Database Management Systems",
  "Software Design & Architecture",
  "Cybersecurity Fundamentals",
];

export const languages = ["English", "Hindi", "Gujarati", "Marathi"];

export const hobbies = [
  "Playing Badminton",
  "Reading Non-Fiction (especially stories of real-life heroes)",
];
